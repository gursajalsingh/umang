<header class = "navbar navbar-inverse navbar-fixed-top" >
			<div class = "container">
				<a href = "inde.php" class = "navbar-brand"> Admin Panel </a>
				<u1 class = "nav navbar-nav navbar-right"> 
					<li><a href = "index.php">Home</a></li>
					<li><a href = "#">Log Out</a></li>
				</u1>
			</div>
		</header>