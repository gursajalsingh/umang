# Student-Fee-Management-System

Project Was  Made Using HTML, CSS, BOOTSTRAP, PHP.


##Requirements-

1. Install the XAMPP
2. Copy the files folder(CS223/files) in the C:\\xampp/htdocs

##Installing the DB:-

1. Run the XAMPP application (make sure that the apache and mysql are running).

2.Open Browser (google chrome, mozilla firefox)

3.Type the url localhost/phpmyadmin

4.Create DB with the name suthar

5.Click the created DB and import the sql (suthar.sql){CS 223/database}




##Accessing the system

1.Run the XAMPP application (make sure that the apache and mysql are running)

2.Open Browser (google chrome, mozilla firefox)

3.type in the url (localhost/files/)

4.ENJOY!



#######---> live Working Website      <---#######

Because of free hosting loading speed may be slow due to limited broadcasting speed.

type the url in the Browser ---->  http://studentfeemanagement.esy.es/

login id for student is --> student1@gmail.com
              password ---> student1
              
              ######  ENJOY! :)      ######
