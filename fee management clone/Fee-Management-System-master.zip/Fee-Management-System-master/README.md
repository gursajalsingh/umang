# Fee Management System

A fee management system which allows students to pay tuition fees and admin to manage and track student accounts. Built using PHP (backend) and pure HTML and CSS (front-end).
